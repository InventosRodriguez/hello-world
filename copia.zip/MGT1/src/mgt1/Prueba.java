package mgt1;

import java.util.Scanner;
//esta es la clase principal donde va el main
public class Prueba {
	//TODO
	/**
	 * 1 PEDIR PESO
	 * 2 PEDIR ESTATURA
	 * 3 CALCULAR IMC
	 * 4 MOSTRAR RESULTADO
	 */

	public static void main (String [] argumentos)
	{
		//Prueba prueba = new Prueba();
		System.out.println("Introduce tu Peso");
		
		//sc es el objeto q estoy creando
		Scanner sc = new Scanner(System.in);
		
		//guardo lo que meti en ventana en la variable nombre
		double peso = sc.nextDouble();
		//displayo peso
		System.out.println(peso);
		
		System.out.println("Introduce tu altura");
		//sc es el objeto q estoy creando
		Scanner al = new Scanner(System.in);
				
		//guardo lo que meti en ventana en la variable nombre
		double altura = al.nextDouble();
		//displayo peso
		System.out.println(altura);
		
		double imc = peso /(altura * altura);
		System.out.println(imc);
		
		//TODO para mostrar el mensaje de tu imc
		if (imc < 16)
		{
			System.out.println("Estas mu flaco");
		} else {
				if ((imc >= 16) && (imc < 18))
				{
				System.out.println("Estas caca");
				} else {
					if ((imc >= 18) && (imc < 25))
					{
					System.out.println("Estas normal");
					} else {
						if ((imc >= 25) && (imc < 30))
						{
						System.out.println("Estas con sobrepeso");
						} else {
							if (imc >= 30)
							{
							System.out.println("Estas obeso");
							}
					}
				}
			}
		}
//		float b = 0;
//		
//		for (int a=0; b<6; a++)
//		{
//			b=a%6;
//			System.out.println (a);
//		}
		
	}

}
