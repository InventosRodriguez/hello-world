package mgt1;
/** para generar despues la documentacion
 * 
 * @author Tania
 *
 */
public class Persona {

		//comenta cosas leches
		//esto es atributo de la clase, por eso es est�tico
		private static int n_personas;
		
		/*
		 * Estos son los atributos:
		 */
		//declarando una variable tipo+nombre de forma privada
		//si quieren acceder ser� a trav�s de un m�todo
		private int edad; //se inicializa a 0
		private String nombre; //se inicializa a null

		
		//me creo mi propio constructor (es un m�todo especial porque se llama igual que la propia clase y sirve para crear objetos-hijos de esa clase
		public Persona ()
		{
			//constructor por defecto
			Persona.n_personas = Persona.n_personas + 1;
		}
		
		//this en un metodo es el objeto q se esta creando
		public Persona (int edadp, String nombrep)
		{
			Persona.n_personas = Persona.n_personas + 1;
			this.edad = edadp;
			this.nombre = nombrep;
		}
		
		//this en un metodo es el objeto llamante (metodo dinamico)
		public void mostrar ()
		{
			System.out.println("Nombre= " + this.nombre);
			System.out.println("Edad= " + this.edad);
		}
		
	// esto sale al a�adir el m�todo main
	public static void main(String[] args) {
	
		System.out.println("PRIMERA CLASE" + 20);
		System.out.println("N_personas " + Persona.n_personas);
		
		Persona p2julio = new Persona(33, "Julio");
		p2julio.mostrar();
		System.out.println("N_personas " + Persona.n_personas);
		
		Persona p3eli = new Persona(37, "Eli");
		p3eli.mostrar();
		System.out.println("N_personas " + Persona.n_personas);
		
		//person es una variable osease objeto Persona es la clase
		Persona person = new Persona(); //invoco al constructor con este m�todo
										//se define impl�citamente para cada clase
		//person es el objeto
		if ((person.edad == 0)&&(person.nombre == null)) 
		{
			System.out.println("TODO EN ORDEN");
		} else 
			{
			System.out.println("UPSSSS");
			}
	}

}
