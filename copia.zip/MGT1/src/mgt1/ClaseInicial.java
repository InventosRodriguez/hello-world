package mgt1;

public class ClaseInicial {

}
