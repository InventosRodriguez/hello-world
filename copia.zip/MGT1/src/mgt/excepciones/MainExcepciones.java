package mgt.excepciones;

public class MainExcepciones {

	public static void main(String[] args) {
		
		int[] array_enteros = new int[3];
		
		try{ //intenta hacer esto
		
			for (int z=0; z<=array_enteros.length; z++) //estoy provocando un error con el <=
			{
				System.out.println(array_enteros[z]);
			}
			System.out.println("Mostr� el array");
		} 
		//a�ado varios catch: el ultimo sera el throwable, sino no compila
		catch (ArrayIndexOutOfBoundsException ex) //si da el error que indico: 
			{
				System.out.println("Capturo excepci�n");
				ex.printStackTrace(); //pinta la informaci�n de la excepci�n
			}
		catch (Throwable ex) //si pongo la excepcion generica, entra da igual cual sea el error
		//catch (ArrayIndexOutOfBoundsException ex) //si da el error que indico: 
		{
			System.out.println("Capturo excepci�n general");
			ex.printStackTrace(); //pinta la informaci�n de la excepci�n
		}

		
	}
	
}
