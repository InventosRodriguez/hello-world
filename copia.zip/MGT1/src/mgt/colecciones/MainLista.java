package mgt.colecciones;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import mgt.cervezas.Cerveza;

public class MainLista {
	
	public static void mostrarLista(List<Cerveza> lista_quellega) { //si pongo list tb funciona porque es la clase padre
	//public static void mostrarLista(ArrayList<Cerveza> lista_quellega) { //entre los parentesis ponemos el tipo de dato y el nombre de la variable donde viaja el dato
		for (Cerveza i : lista_quellega) {
			System.out.println(i.toString());
		}
		
		//para el for normal, como esto es un array list, en vez del .length tenemos el .size para saber lo q ocupe
		for (int i=0; i<lista_quellega.size(); i++){

			System.out.println(lista_quellega.get(i));
		}
		
		//con el iterator, separamos la estructura, de la forma de recorrerla
		Iterator<Cerveza> i_cerveza = lista_quellega.iterator();
		while (i_cerveza.hasNext()) { //mientras haya m�s
			System.out.println(i_cerveza.next());
		}
	}

	public static void main(String[] args) { //args tambien es un nombre de una variable, puedo cambiarlo, es solo el campo de comunicacion
		
		List<Cerveza> lista_cerves = null; //cambio a List porque lo he cambiado en el m�todo mostrarLista
		//ArrayList<Cerveza> lista_cerves = null; //aqu� lo creas pero no tiene memoria
		lista_cerves = new LinkedList<Cerveza>(); //ahora puedo usar linkedlist porque estoy tirando de la clase padre List
		//lista_cerves = new ArrayList<Cerveza>(); //este seria el constructor de la clase arraylist
												//le puedo indicar el tama�o en los par�ntesis
												//he dado memoria a lista_cerves que lo hab�a creado en la l�nea anterior
		
		//ArrayList<Cerveza> lista_cerves = new ArrayList<Cerveza>(); se podr�a hacer en una sola l�nea
		
		Cerveza c1 = new Cerveza("CostaOeste", 2);
		Cerveza c2 = new Cerveza("HappyOtter", 2);
		Cerveza c3 = new Cerveza("PunkIpa", 3);
		
		lista_cerves.add(c1);
		lista_cerves.add(c2);
		lista_cerves.add(c3);
		
		mostrarLista(lista_cerves);
		
	}
	
}
