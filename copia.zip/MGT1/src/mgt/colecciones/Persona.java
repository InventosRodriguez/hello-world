package mgt.colecciones;

public class Persona implements Comparable<Persona>{ //a�ado implements comparable para ordenar, esto me obliga a definir el metodo de la interfaz Comparable
//esta clase tan sencilla ser�a un bean
	private String nif;
	private String nombre;
	private int edad;
	
	@Override
		public String toString() {
			// TODO Auto-generated method stub
			
			return this.nombre + " " + this.edad;
		}
	
	public String getNif() {
		return nif;
	}
	public void setNif(String nif) {
		this.nif = nif;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getEdad() {
		return edad;
	}
	public void setEdad(int edad) {
		this.edad = edad;
	}
	public Persona(String nif, String nombre, int edad) {
		this.nif = nif;
		this.nombre = nombre;
		this.edad = edad;
	}

	/**
	 * Si el entero es >0: this es > que o
	 * Si el entero es =0: this es = que o
	 * Si el entero es <0: this es < que o
	 */
	@Override
	public int compareTo(Persona o) { //me obliga a incluir este metodo al a�adir la interfaz Comparable
		// TODO Auto-generated method stub
		System.out.println("Llamando a comparar" + " " + this);
		int entero_comp = 0;
		
		entero_comp = this.edad - o.edad; //al restarlo, si this.edad es >, devuelve positivo, si es = da 0, si es > da un negativo
											//esto vale por que son datos integer
		
//		if (this.edad >	o.edad) entero_comp = 1;
//		else if (this.edad == o.edad) entero_comp = 0;
//		else entero_comp = -1;
			
		return entero_comp;
	}
}
