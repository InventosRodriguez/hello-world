package mgt.colecciones;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class MainPersonas {

	public static void main(String[] args) {
		
		Map<String, Persona> m_personas = new HashMap<String, Persona>(); //tengo un objeto tipo mapa vac�o
		Persona p1 = new Persona("53130983J", "Valeriano", 33);
		Persona p2 = new Persona("32684931E", "Tania", 34);
		Persona p3 = new Persona("32684930J", "Telmo", 29);
		
		m_personas.put(p1.getNif(), p1); //en el put indico clave y objeto, mmi mapa ya tiene datos
		m_personas.put(p2.getNif(), p2);
		m_personas.put(p3.getNif(), p3);
		
		Persona p = m_personas.get(p3.getNif()); //el get me devuelve un objeto Persona, as� que lo guardo en un objeto "p" de la clase Persona
		
		System.out.println(p.toString());
		
		//colecciones ordenacion
		System.out.println("Mostrando Lista Personas");
		ArrayList<Persona> alp = new ArrayList<>(m_personas.values());
		
		for (Persona per : alp)
		{
			System.out.println(per); //lo muestra seg�n le cuadra porque no se ha guardado de una forma ordenada concreta
		}
		
		//vamos a ordenar por edad (orden natural)
		Collections.sort(alp); //la clase collections tiene el metodo sort, tambien podr�a indicarle qu� comparador usar, pero sino coge el de la clase Persona
								//se est� llamando por dentro al metodo compareto, esto ser�a un callback
		System.out.println("Mostrando lista personas ordenadas");
		for (Persona per : alp)
		{
			System.out.println(per); //ahora saldr�n ordenados por edad porque collections.sort llama a mi metodo compareto para saber el orden
		}
		
		if ((p1.compareTo(p2)) > 0) //puedo invocarlo
		{
			System.out.println("P1 es mayor");
		} else {
			System.out.println("P2 es mayor");
		}
		
		//voy a por el orden total
		ComparaPersonas cp = new ComparaPersonas(); //creo el objeto cp de la clase ComparaPersonas
		Collections.sort(alp, cp); //le paso la lista y el criterio que est� en la clase ComparaPersonas, as� que tengo que crear un objeto de ComparaPersonas "cp"
		System.out.println("Mostrando lista personas ordenadas por orden total");
		
		for (Persona per : alp)
		{
			System.out.println(per); //ahora saldr�n ordenados por edad porque collections.sort llama a mi metodo compareto para saber el orden
		}
	}
	
}
