package mgt.cuentos;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Properties;

public class MainCuentos {

	public static void main(String[] args) throws Throwable {
		
		String idioma = null;
		idioma = args[0];
		System.out.println("idioma" + " " + idioma);
		
		switch (idioma) {
		case "ES":
			
			System.out.println("entro ES");
			Properties espanol = new Properties(); //creo objeto propiedades
			espanol.load(new FileReader("story_es.properties"));
			String nom_fichero = espanol.getProperty("outfile");
			System.out.println("nombre fichero" + nom_fichero);
			
			File o_file = new File(nom_fichero);
			
			if (!o_file.exists())
			{
				o_file.createNewFile();
				System.out.println("creo fichero");
			}
			
			FileWriter f_escr = new FileWriter(o_file);
			BufferedWriter bw = new BufferedWriter(f_escr);
			String start = espanol.getProperty("start");
			System.out.println("texto 1" + start);
			
			bw.write(start); //escribe en un registro
			bw.newLine();
			
			String body = espanol.getProperty("body");
			
			bw.write(body); //escribe en un registro
			bw.newLine();
			
			String end = espanol.getProperty("end");
			
			bw.write(end); //escribe en un registro
			bw.newLine();
			
			bw.close();
			
			break;
			
		case "IT":
			System.out.println("entro IT");
			Properties italiano = new Properties(); //creo objeto propiedades
			italiano.load(new FileReader("story_it.properties"));
			String nom_ficheroit = italiano.getProperty("outfile");
			System.out.println("nombre fichero" + nom_ficheroit);
			
			File o_fileit = new File(nom_ficheroit);
			
			if (!o_fileit.exists())
			{
				o_fileit.createNewFile();
				System.out.println("creo fichero");
			}
			
			FileWriter f_escrit = new FileWriter(o_fileit);
			BufferedWriter bwit = new BufferedWriter(f_escrit);
			String startit = italiano.getProperty("start");
			System.out.println("texto 1" + startit);
			
			bwit.write(startit); //escribe en un registro
			bwit.newLine();
			
			String bodyit = italiano.getProperty("body");
			
			bwit.write(bodyit); //escribe en un registro
			bwit.newLine();
			
			String endit = italiano.getProperty("end");
			
			bwit.write(endit); //escribe en un registro
			bwit.newLine();
			
			bwit.close();
			break;
			
		case "EN":
			System.out.println("entro EN");
			Properties ingles = new Properties(); //creo objeto propiedades
			ingles.load(new FileReader("story_en.properties"));
			String nom_ficheroin = ingles.getProperty("outfile");
			System.out.println("nombre fichero" + nom_ficheroin);
			
			File o_filein = new File(nom_ficheroin);
			
			if (!o_filein.exists())
			{
				o_filein.createNewFile();
				System.out.println("creo fichero");
			}
			
			FileWriter f_escrin = new FileWriter(o_filein);
			BufferedWriter bwin = new BufferedWriter(f_escrin);
			String startin = ingles.getProperty("start");
			System.out.println("texto 1" + startin);
			
			bwin.write(startin); //escribe en un registro
			bwin.newLine();
			
			String bodyin = ingles.getProperty("body");
			
			bwin.write(bodyin); //escribe en un registro
			bwin.newLine();
			
			String endin = ingles.getProperty("end");
			
			bwin.write(endin); //escribe en un registro
			bwin.newLine();
			
			bwin.close();
			break;

		default:
			break;
		}
	}
}
