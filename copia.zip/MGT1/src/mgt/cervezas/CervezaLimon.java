package mgt.cervezas;

public class CervezaLimon extends Cerveza {

	public static final float PRECIO_LIMON = 3.f; //para ayudar al compilador, le indico q el valor es en float con el .f, si fuese double .d
	
	
	public CervezaLimon(String nombre, int cantidad, float precio)
	{
		super(nombre, cantidad); //aqu� super llama al constructor del padre (estoy dentro de un constructor del hijo, super va al del padre)
		this.setPrecio(PRECIO_LIMON);
		
	}
}
