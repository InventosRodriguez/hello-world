package mgt.cervezas;

public class CervezaSin extends Cerveza {
	
	public static final float PRECIO_SIN = 1.f;
	
	
	public CervezaSin(String nombre, int cantidad, float precio)
	{
		super(nombre, cantidad); //aqu� super llama al constructor del padre (estoy dentro de un constructor del hijo, super va al del padre)
		this.setPrecio(PRECIO_SIN);
		
	}
}
