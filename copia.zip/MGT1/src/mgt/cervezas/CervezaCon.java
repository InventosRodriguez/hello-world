package mgt.cervezas;

public class CervezaCon extends Cerveza {

	public static final float PRECIO_CON = 2.f;
	
	
	public CervezaCon(String nombre, int cantidad, float precio)
	{
		super(nombre, cantidad); //aqu� super llama al constructor del padre (estoy dentro de un constructor del hijo, super va al del padre)
		this.setPrecio(PRECIO_CON);
		
	}
}
