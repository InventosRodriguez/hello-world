package mgt.cervezas;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class PrincipalCervezas {
	//static y final les llama modificadores
	public static final int N_TIPO_CERVEZAS = 3; //final es para constantes
												//les ponen nombre en may�sculas
	//creando metodo escribir ventas
	public static void escribirVentas(Cerveza[] array_cerves, String nom_fichero) throws IOException //el throw esta aqui y en el catch
	{
		File o_file = new File(nom_fichero);
		
		try
		{ //intenta ejecutar este codigo
		
			if (!o_file.exists())
			{
				o_file.createNewFile();
			}
		
			FileWriter f_escr = new FileWriter(o_file);
			BufferedWriter bw = new BufferedWriter(f_escr);
		
			Cerveza cerve_aux = null;
			String linea_aux = null;
		
			for (int i=0; i < N_TIPO_CERVEZAS; i++) //podemos cambiar el N_TIPO por array_cerves.length
				{
				cerve_aux = array_cerves[i];
				linea_aux = cerve_aux.toString(); //el to string te convierte la info del array a texto
				bw.write(linea_aux); //escribe en un registro
				bw.newLine(); //mete el salto de linea para que cuando escribas el siguiente lo haga en un registro nuevo
				
					//bw.write(array_cerves[i].toString()); esto es en modo pro
				}
			bw.close(); //no olvidar el close!!!
		}
		catch (IOException iox) //y si da un pete el tema de ficheros, escribe el error
		{
			iox.printStackTrace();
			throw iox; //tiene q estar tambien arriba, en la entrada del metodo
		}
//		for (Cerveza c1 : array_cerves) as� ser�a el for each
//		{
//			
//		}
		
	}
	
	
	private static int pedirCervezas (String tipo)
	{
		int num_cerves = 0;
		
		System.out.println("�Cuantas de " + tipo + "?"); //envio el mensaje
		Scanner scanner = new Scanner(System.in); //recojo lo que introduzco
		num_cerves = scanner.nextInt();
		
		return num_cerves;
	}
	
	public static void main(String[] args) throws IOException { //los objetos se crean siempre desde el main
		// TODO El Bar de MGT: a ver cuanto bebemos
		
		Cerveza[] cervezas = null; //inicializamos los objetos a null, un array
		cervezas = new Cerveza[N_TIPO_CERVEZAS]; //creo el objeto cervezas de la clase 
												//Cerveza que es un array occurs 
												//TIPO_CERVEZA
												//los array empiezan en 0
		
		//bucle for: se repite un numero de veces sin preguntar por condicion
		for (int i=0; i<N_TIPO_CERVEZAS; i++)
		{
			switch (i) {  //el switch equivale al evaluate, pero no hay evaluate true ni puedes preguntar por mas de un campo

			case 0: //fila 0 es cerveza con limon
				//defino un entero que recepciona el valor que devuelve el m�todo pedirCervezas
				//para llamar a un m�todo, se llama para algo, osea que el call se hace simplem
				//al escribir pedirCervezas("LIMON"), es como llamar a una funcion
				int n_limon = pedirCervezas("LIMON");
				
				CervezaLimon cl = new CervezaLimon("LIMON", n_limon, CervezaLimon.PRECIO_LIMON); //el objeto es cl, y le digo q es de la clase CervezaLimon
														//como hemos definido cervezalimon con hijo de cerveza, al poner cl. me deja asignar los metodos de la clase
														//cerveza
				cl.setNombre("LIMON"); //ahora le doy valor a los atributos de mi objeto
				cl.setCantidad(n_limon); //lo mismo, de esta forma voy creando las columnas de la tabla
				//cervezas[i] = cl;
				
				//Cerveza cl = new Cerveza("LIMON", n_limon); //si llamo al m�todo de la clase Cerveza, ya me asigna los atributos a mi objeto
															//as� no los tengo que asignar uno por uno
				cervezas[i] = cl;
				
				break;
			
			case 1: //fila 1 es cerveza SIN
				int n_sin = pedirCervezas("SIN");
				CervezaSin csin = new CervezaSin("SIN", n_sin, CervezaSin.PRECIO_SIN);
				//csin.setNombre("SIN"); 
				//csin.setCantidad(n_sin);
				cervezas[i] = csin;
				
				break;
			
			case 2: //fila 2 es cerveza CON
				int n_con = pedirCervezas("CON");
				CervezaCon ccon = new CervezaCon("CON", n_con, CervezaCon.PRECIO_CON);
				//ccon.setNombre("CON"); 
				//ccon.setCantidad(n_con);
				cervezas[i] = ccon;
				
				break;

			default:
				break;
			}
		} //fin for de pedir
		
		//vamos a usar un for each, para cada cerveza del array, defino c q es el �ndice que va aumentando de 1 en 1, cervezas es el array
		for (Cerveza c : cervezas)
		{
			//System.out.println(c.getNombre() + " " + c.getCantidad()); //displayo cada columna de la fila
			System.out.println(c.toString()); //displayo lo que hay en tostring
		} //c solo existe dentro de las llaves
		
		escribirVentas(cervezas, "informe");
		
		//con el for normal:
//		for (int i=0; i<N_TIPO_CERVEZAS; i++)
//		{
//			Cerveza c_aux = cervezas[i];
//			System.out.println(c_aux.getNombre() + " " + c_aux.getCantidad());
//		} //caux solo existe dentro de las llaves, fuera de la llave caux ya no existe.

	}
}
