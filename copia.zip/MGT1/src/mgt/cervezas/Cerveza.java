package mgt.cervezas;
/**
 * TENEMOS UN BAR Y QUEREMOS REGISTRAR LA CANTIDAD DE CERVEZA DE CADA TIPO QUE
 * SE HA VENDIDO
 * HAY 3 TIPOS: SIN (1�), CON (2�), CON LIMON (3�)
 * DE CADA CERVEZA SE ALMACENA EL PRECIO Y LA CANTIDAD
 * QUEREMOS SACAR UN LISTADO CON LAS VENTAS
 * 
 * @author Tania
 *
 */
//nombre de la clase, esta clase sencilla que tiene atributos y metodos: BEAN, JAVA BEAN, POJO
public class Cerveza {
	//atributos siempre tienen que ser privados
	private String nombre; //el sin, el con o el con limon
	private int cantidad; //cantidad de cerveza que se ha vendido
	private float precio; //precio de la cerveza
	
	//metodos
	public Cerveza() //este es el constructor
	{
		
	}
	
	//hacemos nuestra version del tostring para dar m�s informaci�n
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		String cervestring = null;
		//return super.toString(); //aqui estamos llamando al toString original
		cervestring = this.nombre + " " + this.cantidad + " " + this.calcular();
		
		return cervestring;
	}
	
	public Cerveza(String nombre, int cantidad) //constructor creado por nosotros
	{
		this.nombre = nombre;
		this.cantidad = cantidad;
	}
	
	//metodo para calcular
	public float calcular(){ //no me hace falta pasarme nada porque cantidad y precio son atributos del objeto que me llama
		float valorventa = 0;
		valorventa = this.cantidad * this.precio;
		return valorventa;
	}
	
	//estos son metodos especiales, sirven para acceder a los atributos, q son privados, pero el petodo es publico
	//boton derecho->source->getters a setters
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getCantidad() {
		return cantidad;
	}

	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}

	public float getPrecio() {
		return precio;
	}

	public void setPrecio(float precio) {
		this.precio = precio;
	}
	
	
}
