package mgt.ficheros;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class MainFicheros {

	public static void main(String[] args) throws IOException { //ponemos el throw para que se propague el error
		File o_file = new File("f1.txt");
		
		if (o_file.exists())
		{
			System.out.println("El fichero existe");
			FileReader f_leer = new FileReader(o_file); //el primero es la clase y el segundo el m�todo
														//f_leer ser�a una variable tipo FileReader

			BufferedReader br = new BufferedReader(f_leer); //creo objeto tipo BR pasandole un objeto tip FR
			String linea = null; //la respuesta de readLine es un string as� que me defino uno para guardarlo
			while ((linea=br.readLine()) != null) //leo una linea, cuando llegue al final readLine devuelve null
			{										//mientras no me devuelva null, sigo en el bucle
				System.out.println(linea);
			}
			
			//Object o_leer = (Object)f_leer; //casting de pasar de tipo fichero a tipo objeto
			
			//probamos read, esto lee de byte a byte, osea una caca
//			int b_leido = 0;
//			while ((b_leido = f_leer.read()) != -1) //devuelve un -1 al llegar a fin fichero
//			{
//				char letra = (char)b_leido; //llamamos casting el transformar tipos, en este caso entero a char
//				System.out.println(b_leido + "-" + letra);
//				
//			}
			
			//f_leer.close();
			br.close();

			
		} else {
			System.out.println("El fichero NO existe");
			
			o_file.createNewFile(); //creo el fichero y ya se queda "abierto"
									//devuelve un booleano con si se ha creado o no, tiene un control de errores de fichero, tipo file-status
			System.out.println("El fichero se ha creado");
		
		}
	}	
}
